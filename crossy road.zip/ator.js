//código do ator
let xAtor = 130;
let yAtor = 760;
let colisao = false;
let meusPontos = 0;


function mostraAtor(){
  image(imagemDoAtor, xAtor, yAtor, 40, 40);
}

function movimentaAtor(){
  if (keyIsDown(UP_ARROW)){
    yAtor -=3
  }
  
  if (keyIsDown(DOWN_ARROW)){
  if (podeSeMover()){
    yAtor +=3
    } 
  }
}

function verificaColisao(){
  for (let i = 0; i < imagemCarros.length; i++){
  colisao = collideRectCircle 
  (xCarros[i], yCarros [i], lCarros[i], cCarros[i], xAtor, yAtor, 15) 
  if (colisao){voltaAtorPosicaoInicial(); somDaColisao.play();
    }
  }
}

function voltaAtorPosicaoInicial(){
  yAtor = 760
}

function incluiPontos(){
  textSize(40);
  fill (139,0,0)
  text(meusPontos, 95, 70);
}

function marcaPontos(){
  if (yAtor < 200){meusPontos += 1; voltaAtorPosicaoInicial();somDoPonto.play();
  }
   if (colisao  && meusPontos > 0){meusPontos -=1;
  }
}

function podeSeMover(){
  return yAtor < 760;
  
}