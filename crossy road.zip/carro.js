//código dos carros
let xCarros = [1200, 1200, 1200, 1200, 1200, 1200, 1800, 1800]
let yCarros = [255, 330, 420, 515, 595, 678, 255, 680];
let vCarros = [5, 8, 7, 5.5, 9, 7.2, 5, 7.2];
let lCarros = [130, 110, 90, 110, 110, 110, 130, 90];
let cCarros = [65, 60, 55, 55, 60, 55, 65, 55]

function mostrarCarro(){
   for (let i = 0; i < imagemCarros.length; i++){
    image(imagemCarros[i], xCarros[i],
          yCarros[i], lCarros[i], cCarros[i]);
  }
}

function movimentaCarros(){
  for (let i = 0; i <imagemCarros.length; i++ ){
    xCarros[i] -= vCarros[i];
  }
}

function voltaPosicaoInicialDoCarro(){
for (let i = 0; i <imagemCarros.length; i++ ){
if (passouTodaTela(xCarros[i])){xCarros[i] = 1200
    }
  }
}

function passouTodaTela(xCarro){
return xCarro < -110;
}