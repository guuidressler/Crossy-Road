function setup() {
  somDaTrilha.loop();
  createCanvas(1200, 800);
}

function draw() {
  background(imagemDaEstrada);
  mostraAtor();
  mostrarCarro();
  movimentaCarros();
  movimentaAtor();
  voltaPosicaoInicialDoCarro();
  verificaColisao();
  incluiPontos();
  marcaPontos();
}
